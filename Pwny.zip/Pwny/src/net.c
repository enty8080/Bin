/*
 * MIT License
 *
 * Copyright (c) 2020-2023 EntySec
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <log.h>
#include <ev.h>

#include <net.h>
#include <loop.h>
#include <queue.h>

static int non_block_sock(int sock)
{
#ifdef _WIN32
    unsigned long non_block;

    non_block = 1;

    if (ioctlsocket(sock, FIONBIO, &non_block) == SOCKET_ERROR)
    {
        return -1;
    }
#else
    int flags;

    if ((flags = fcntl(sock, F_GETFL, NULL)) < 0)
    {
        return -1;
    }

    if (!(flags & O_NONBLOCK))
    {
        if (fcntl(sock, F_SETFL, flags | O_NONBLOCK) == -1)
        {
            return -1;
        }
    }
#endif

    return 0;
}

void net_set_timer(net_t *net, loop_timer_t timer_cb)
{
    net->timer_cb = timer_cb;
}

void net_set_read(net_t *net, loop_cb_t read_cb)
{
    net->read_cb = read_cb;
}

void net_start(net_t *net)
{
    if (non_block_sock(net->sock) == 0)
    {
        ev_io_init(&net->io, net->read_cb, net->sock, EV_READ);

        net->io.data = net;
        ev_io_start(net->loop, &net->io);

        ev_timer_init(&net->timer, net->timer_cb, 0, 0.1);
        net->timer.data = net;
        ev_timer_start(net->loop, &net->timer);
    }
}

net_t *net_create(struct ev_loop *loop)
{
    net_t *net;

    net = calloc(1, sizeof(*net));

    if (net != NULL)
    {
        net->read_queue = queue_create();
        if (net->read_queue == NULL)
        {
            goto fail;
        }

        net->write_queue = queue_create();
        if (net->write_queue == NULL)
        {
            goto fail;
        }

        net->loop = loop;
        net->proto = NET_PROTO_TCP;

        net_set_read(net, net_read_cb);
        net_set_timer(net, net_timer_cb);

        return net;
    }

    return NULL;

fail:
    net_free(net);
    return NULL;
}

void net_read_tcp(net_t *net)
{
    int error;
    size_t bytes;
    ssize_t stat;
    char buffer[NET_QUEUE_SIZE];

    log_debug("* Read TCP event initialized (%d)\n", net->sock);

    while ((stat = read(net->sock, buffer, sizeof(buffer))) > 0)
    {
        log_debug("* Read bytes via TCP (%d) - (%d)\n", net->sock, stat);
        queue_add_raw(net->read_queue, buffer, stat);
        bytes += stat;
    }

    error = errno;

    if (stat == 0)
    {
        log_debug("* Read TCP connection shutdown (%d)\n", net->sock);
        ev_io_stop(net->loop, &net->io);
    }
    else if (stat == -1 && error != EAGAIN && error != EINPROGRESS && error != EWOULDBLOCK)
    {
        log_debug("* Read TCP connection terminated (%d)\n", net->sock);
        ev_io_stop(net->loop, &net->io);
    }
}

void net_write_tcp(net_t *net)
{
    size_t size;
    ssize_t stat;
    ssize_t offset;
    void *buffer;

    buffer = NULL;
    offset = 0;

    if (net->write_queue->bytes <= 0)
    {
        return;
    }

    while ((size = queue_remove_all(net->write_queue, &buffer)) > 0)
    {
        log_debug("* Writing bytes to TLV (%d) - (%d)\n", net->sock, size);

        do
        {
            stat = send(net->sock, buffer + offset, size - offset, 0);

            if (stat > 0)
            {
                offset += stat;
            }

            log_debug("* Write bytes via TCP (%d) - (%d)\n", net->sock, stat);
        }
        while (stat > 0);

        free(buffer);
    }
}

void net_read_cb(struct ev_loop *loop, struct ev_io *w, int events)
{
    net_t *net;

    net = w->data;

    switch (net->proto)
    {
        case NET_PROTO_TCP:
            net_read_tcp(net);
            break;
        default:
            break;
    }
}

void net_timer_cb(struct ev_loop *loop, struct ev_timer *w, int revents)
{
    net_t *net;

    net = w->data;

    switch (net->proto)
    {
        case NET_PROTO_TCP:
            net_write_tcp(net);
            break;
        default:
            break;
    }
}

void net_free(net_t *net)
{
    ev_io_stop(net->loop, &net->io);
    ev_timer_stop(net->loop, &net->timer);

    queue_free(net->read_queue);
    queue_free(net->write_queue);

    close(net->sock);
    free(net);
}
