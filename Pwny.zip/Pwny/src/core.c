/*
 * MIT License
 *
 * Copyright (c) 2020-2023 EntySec
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <signal.h>

#include <c2.h>
#include <core.h>
#include <tlv.h>
#include <tab.h>
#include <tlv_types.h>
#include <log.h>
#include <ev.h>
#include <eio.h>
#include <api.h>
#include <net.h>

static struct ev_idle eio_idle_watcher;
static struct ev_async eio_async_watcher;

static void eio_idle_cb(struct ev_loop *loop, struct ev_idle *w, int revents)
{
	if (eio_poll() != -1) {
		ev_idle_stop(loop, w);
	}
}

static void eio_async_cb(struct ev_loop *loop, struct ev_async *w, int revents)
{
	if (eio_poll() == -1) {
		ev_idle_start(loop, &eio_idle_watcher);
	}

	ev_async_start(ev_default_loop(CORE_EV_FLAGS), &eio_async_watcher);
}

static void eio_want_poll(void)
{
	ev_async_send(ev_default_loop(CORE_EV_FLAGS), &eio_async_watcher);
}

static void eio_done_poll(void)
{
	ev_async_stop(ev_default_loop(CORE_EV_FLAGS), &eio_async_watcher);
}

static void core_signal_handler(struct ev_loop *loop, ev_signal *w, int revents)
{
    switch (w->signum)
    {
		case SIGINT:
		    log_debug("* Core has SIGINT caught\n");
		    ev_break(loop, EVBREAK_ALL);
		    break;

		case SIGTERM:
		    log_debug("* Core has SIGTERM caught\n");
			ev_break(loop, EVBREAK_ALL);
			break;

		default:
			break;
	}
}

static tlv_pkt_t *core_request_cb(c2_t *c2)
{
    int tag;
    int status;
    int tab_id;

    tlv_pkt_t *response;

    if (tlv_pkt_get_int(c2->request, TLV_TYPE_TAG, &tag) < 0)
    {
        log_debug("* No tag was received from (%d)\n", c2->sock);
        return api_craft_tlv_pkt(API_CALL_NOT_IMPLEMENTED);
    }

    log_debug("* Read new tag (%d) from (%d)\n", tag, c2->sock);

    if ((response = api_call_make(&c2->dynamic.api_calls, c2, tag)) == NULL)
    {
        if (tlv_pkt_get_int(c2->request, TLV_TYPE_TAB_ID, &tab_id) >= 0)
        {
            if (tab_lookup(&c2->dynamic.tabs, tab_id, c2->request) >= 0)
            {
                return NULL;
            }

            response = api_craft_tlv_pkt(API_CALL_NOT_IMPLEMENTED);
        }
        else
        {
            response = api_craft_tlv_pkt(API_CALL_NOT_IMPLEMENTED);
        }
    }

    if (tlv_pkt_get_int(response, TLV_TYPE_STATUS, &status) >= 0)
    {
        if (status == API_CALL_QUIT)
        {
            return NULL;
        }
    }

    return response;
}

static void core_timer_cb(struct ev_loop *loop, struct ev_timer *w, int revents)
{
    c2_t *c2;

    tlv_pkt_t *request;
    tlv_pkt_t *response;

    c2 = w->data;
    request = tlv_pkt_create();

    if (tlv_pkt_dequeue(c2->net->read_queue, &request) > 0)
    {
        c2->request = tlv_pkt_get_tlv(request, TLV_TYPE_GROUP);

        tlv_pkt_destroy(request);

        if (c2->request == NULL)
        {
            return;
        }

        log_debug("* New TLV packet dequeued (%d bytes, %d objects)\n",
                    c2->request->bytes, c2->request->count);

        if ((response = core_request_cb(c2)) != NULL)
        {
            c2->response = tlv_pkt_create();

            if (c2->response == NULL)
            {
                goto fail;
            }

            tlv_pkt_add_tlv(c2->response, TLV_TYPE_GROUP, response);
            tlv_pkt_enqueue(c2->net->write_queue, c2->response);
            tlv_pkt_destroy(response);

            goto cleanup;
        }

        c2_stop(c2);
        goto cleanup;
    }

    return;

cleanup:
    tlv_pkt_destroy(c2->response);

fail:
    tlv_pkt_destroy(c2->request);
}

core_t *core_create(c2_t *c2)
{
    core_t *core;

    core = calloc(1, sizeof(*core));

    if (core == NULL)
    {
        return NULL;
    }

    core->loop = ev_default_loop(CORE_EV_FLAGS);

    ev_idle_init(&eio_idle_watcher, eio_idle_cb);
    ev_async_init(&eio_async_watcher, eio_async_cb);
    eio_init(eio_want_poll, eio_done_poll);

    core->c2 = c2;
    c2_setup(core->c2, core->loop);

    c2_set_timer(core->c2, core_timer_cb);

    return core;
}

int core_begin(core_t *core)
{
    ev_signal sigint_w, sigterm_w;

    ev_signal_init(&sigint_w, core_signal_handler, SIGINT);
    ev_signal_start(core->loop, &sigint_w);
    ev_signal_init(&sigterm_w, core_signal_handler, SIGTERM);
    ev_signal_start(core->loop, &sigterm_w);

    ev_async_start(core->loop, &eio_async_watcher);

    c2_start(core->c2);
    net_start(core->c2->net);

    return ev_run(core->loop, 0);
}

void core_destroy(core_t *core)
{
    ev_break(core->loop, EVBREAK_ALL);
    free(core);
}
