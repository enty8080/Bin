/*
 * MIT License
 *
 * Copyright (c) 2020-2023 EntySec
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all
 * copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */

#include <signal.h>

#include <c2.h>
#include <core.h>
#include <tlv.h>
#include <tab.h>
#include <tlv_types.h>
#include <log.h>
#include <ev.h>
#include <eio.h>
#include <api.h>
#include <net.h>

static struct ev_idle eio_idle_watcher;
static struct ev_async eio_async_watcher;

static void eio_idle_cb(struct ev_loop *loop, struct ev_idle *w, int revents)
{
	if (eio_poll() != -1) {
		ev_idle_stop(loop, w);
	}
}

static void eio_async_cb(struct ev_loop *loop, struct ev_async *w, int revents)
{
	if (eio_poll() == -1) {
		ev_idle_start(loop, &eio_idle_watcher);
	}

	ev_async_start(ev_default_loop(CORE_EV_FLAGS), &eio_async_watcher);
}

static void eio_want_poll(void)
{
	ev_async_send(ev_default_loop(CORE_EV_FLAGS), &eio_async_watcher);
}

static void eio_done_poll(void)
{
	ev_async_stop(ev_default_loop(CORE_EV_FLAGS), &eio_async_watcher);
}

static void core_signal_handler(struct ev_loop *loop, ev_signal *w, int revents)
{
    switch (w->signum)
    {
		case SIGINT:
		    log_debug("* Core has SIGINT caught\n");
		    ev_break(loop, EVBREAK_ALL);
		    break;

		case SIGTERM:
		    log_debug("* Core has SIGTERM caught\n");
			ev_break(loop, EVBREAK_ALL);
			break;

		default:
			break;
	}
}

static int *core_request_cb(c2_t *c2)
{
    int tag;
    int status;
    int tab_id;

    if (tlv_pkt_get_int(c2->request, TLV_TYPE_TAG, &tag) < 0)
    {
        log_debug("* No tag was received from (%d)\n", c2->sock);
        *c2->response = api_craft_tlv_pkt(API_CALL_NOT_IMPLEMENTED);

        return CORE_LOOP;
    }

    log_debug("* Read new tag (%d) from (%d)\n", tag, c2->sock);

    if (tlv_pkt_get_int(c2->request, TLV_TYPE_TAB_ID, &tab_id) >= 0)
    {
        if (tab_lookup(&c2->dynamic.tabs, tab_id, c2->request) >= 0)
        {
            return CORE_SILENT;
        }

        *c2->response = api_craft_tlv_pkt(API_CALL_NOT_IMPLEMENTED);
        return CORE_LOOP;
    }

    if (api_call_make(&c2->dynamic.api_calls, c2, tag, &c2->response) < 0)
    {
        *c2->response = api_craft_tlv_pkt(API_CALL_NOT_IMPLEMENTED);
        return CORE_LOOP;
    }

    if (c2->response == NULL)
    {
        return CORE_SILENT;
    }

    if (tlv_pkt_get_int(c2->response, TLV_TYPE_STATUS, &status) >= 0)
    {
        switch (status)
        {
            case API_CALL_QUIT:
                return CORE_BREAK;
            default:
                break;
        }
    }

    return CORE_LOOP;
}

static void core_timer_cb(struct ev_loop *loop, struct ev_timer *w, int revents)
{
    c2_t *c2;
    int status;

    if (group_tlv_dequeue(c2->net->ingress, &c2->request) > 0)
    {
        status = core_request_cb(c2);

        switch (status)
        {
            case CORE_BREAK:
                log_debug("* Received CORE_BREAK signal (%d)\n", CORE_BREAK);

                group_tlv_enqueue(c2->net->egress, c2->response);
                c2_stop(c2);

                goto clean_out;

            case CORE_LOOP:
                log_debug("* Received CORE_LOOP signal (%d)\n", CORE_LOOP);

                group_tlv_enqueue(c2->net->egress, c2->response);
                goto clean_out;

            case CORE_SILENT:
                log_debug("* Received CORE_SILENT signal (%d)\n", CORE_SILENT);
                goto clean_in;

            default:
                break;
        }
    }

clean_out:
    tlv_pkt_destroy(c2->response);

clean_in:
    tlv_pkt_destroy(c2->request);
}

core_t *core_create(c2_t *c2)
{
    core_t *core;

    core = calloc(1, sizeof(*core));

    if (core == NULL)
    {
        return NULL;
    }

    core->loop = ev_default_loop(CORE_EV_FLAGS);

    ev_idle_init(&eio_idle_watcher, eio_idle_cb);
    ev_async_init(&eio_async_watcher, eio_async_cb);
    eio_init(eio_want_poll, eio_done_poll);

    core->c2 = c2;
    c2_setup(core->c2, core->loop);

    c2_set_timer(core->c2, core_timer_cb);

    return core;
}

int core_begin(core_t *core)
{
    ev_signal sigint_w, sigterm_w;

    ev_signal_init(&sigint_w, core_signal_handler, SIGINT);
    ev_signal_start(core->loop, &sigint_w);
    ev_signal_init(&sigterm_w, core_signal_handler, SIGTERM);
    ev_signal_start(core->loop, &sigterm_w);

    ev_async_start(core->loop, &eio_async_watcher);

    c2_start(core->c2);
    net_start(core->c2->net);

    return ev_run(core->loop, 0);
}

void core_destroy(core_t *core)
{
    ev_break(core->loop, EVBREAK_ALL);
    free(core);
}
