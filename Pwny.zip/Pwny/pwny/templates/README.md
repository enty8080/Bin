## `pwny/templates`

This endpoint is needed for storing Pwny executable templates.
