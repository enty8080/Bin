## `pwny/plugins`

This endpoint is needed for storing different plugins.
