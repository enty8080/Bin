## `pwny/libs`

This endpoint is needed for storing different executables for plugins.
