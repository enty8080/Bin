## `pwny/data`

This endpoint is needed for storing different data files.
